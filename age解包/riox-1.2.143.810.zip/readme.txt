﻿================================================================================
Software: age Game Graphic/Text Extractor RioX
Version: 1.2.143.810
Author: muzhi
Updated: 2013/10/08
Environment: confirmed in Windows 7,
             supposed to work in other Windows systems
--------------------------------------------------------------------------------
About This Software:
  RioX provides a universal solution to extract resources from age's galgames.
  It extracts graphics and texts from resource packages (*.rio).
  Graphics are saved in png files,
  and texts are saved with offset tags in txt files.
  I hope this software brings galgamers more fun,
  and let's support age and respect their copyrights.
--------------------------------------------------------------------------------
Manual:
  Run RioX.exe, select resource types to extract by checking the boxes,
  and select source file and output directory.
  For text extraction, you can select either "Heuristic Scan" or "Simple Scan".
  Press "Extract" button to start the extraction,
  press "Pause" button to pause/resume, and press "Stop" to terminate.
  The log is printed on the right, and the progress is showed at the bottom.
--------------------------------------------------------------------------------
Notice:
  1. Known package suffixes: .rio, .rio.002, .rio.003, .rio.ruo1, .rio.kdl.
     Input a *.rio file, RioX extracts also the ~.rio.002, ~.rio.003 files.
     Input other files may extract nothing, or even cause a crash.
  2. A large number of files may be saved, please select a proper directory.
  3. In the texts, a few messages may be error or missing.
  4. Not exactly "all" graphics are extracted.
  5. CGs/backrgounds and character sprites are not well distinguished,
     for age changes data types between games to pack the same type of contents.
  6. "Heuristic Scan" provides a better precision than "Simple Scan",
     but may have unkown problems.
  7. During a pause you can modify paths or settings,
     but they will be applied in next extraction --
     after this run is finished or stopped, and "Extract" is pressed again.
--------------------------------------------------------------------------------
Copyright:
  RioX is developed by muzhi personally.
  Anyone can use or redistribute RioX freely.
  The author is not responsible for or any result
  caused by the use or distribution of RioX and its extractions.
--------------------------------------------------------------------------------
Versions:
  2013/10/08 1.2.143.810: Add support to new sprite format in Chronicles 04
  2013/04/23 1.2.137.781: Improve text extraction and add new method
  2012/06/14 1.1.89.524: Add supports to character sprites and texts
  2012/03/30 1.0.6.39: Support CGs/backgrounds
--------------------------------------------------------------------------------
Supported Games:
    マブラヴ 18X
    マブラヴ 全年齢
    マブラヴ　オルタネイティヴ 18X
    マブラヴ　オルタネイティヴ 全年齢
    マブラヴ　サプルメント
    マブラヴ オルタードフェイブル
    マブラヴ　オルタネイティヴ　クロニクルズ 01
    マブラヴ　オルタネイティヴ　クロニクルズ 02
    マブラヴ　オルタネイティヴ　クロニクルズ 03
    マブラヴ　オルタネイティヴ　クロニクルズ 04
    アユマユ オルタネイティヴ
    マブラヴ　オルタネイティヴ アナザーストーリー 継承
    マブラヴ　オルタネイティヴ アナザーストーリー 贖罪
    君がいた季節FR
    君がいた季節 フルボイス (Graphics Only)
    君が望む永遠LE
    君が望む永遠 DVD Specification
================================================================================