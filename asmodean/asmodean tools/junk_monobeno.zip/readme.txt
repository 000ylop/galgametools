I wrote some tools to parse the scenario files but I don't feel like making
them easy for people to use or putting up with them crying about it.

So here's a junk pre-generated script.  This requires ImageMagick.  Files
must already be converted to PNG.  Run it from the "evimage" directory.

Don't bother me about this if you don't understand.

web:   http://asmodean.reverse.net
email: asmodean [at] hush.com
irc:   asmodean on efnet (irc.efnet.net)
