Free software.  Do what you want with it.  Any authors with an interest
in game hacking, please contact me in English or Japanese.

If you do anything interesting with this source, let me know. :)

web:   http://plaza.rakuten.co.jp/asmodean
email: asmodean [at] hush.com
irc:   asmodean on efnet (irc.efnet.net)
icq:   55244079
