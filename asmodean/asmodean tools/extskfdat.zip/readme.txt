This software may not be redistributed, modified or used in other software
without the author's permission.

web:   http://asmodean.reverse.net
email: asmodean [at] hush.com
irc:   asmodean on efnet (irc.efnet.net)
